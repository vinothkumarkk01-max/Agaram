/**
 * A scattered, editorial-style collage of "portrait cards" for the
 * landing-page hero — built in response to founder feedback (Sept
 * 2026): the hero was "almost entirely textual/functional" for a
 * matrimonial product, and should instead show people, framed as
 * "editorial + premium + warm + trustworthy" rather than
 * "swipe + dating + gamification".
 *
 * IMPORTANT — these are NOT real member photos. This sandbox has no
 * way to source licensed photography (no image-generation tool, and
 * outbound fetches to stock-photo CDNs are blocked by the
 * organization's network policy), so each card is an elegant,
 * abstract placeholder: a soft warm gradient plus a simple silhouette
 * bust, framed exactly like a real portrait photo would be (rounded
 * corners, soft shadow, thin border — the same "paper card" treatment
 * as the rest of the Agaramiya Design System). The moment real,
 * licensed portrait photography is available, drop each image into
 * the `photoSrc` slot below and the layout needs no other changes.
 *
 * Never used as a stand-in for a "real testimonial" or "real member" —
 * no names, no quotes, no verified badges are attached to these cards,
 * to stay consistent with the app's honesty-first positioning (no
 * fabricated signals, matching the "no fabricated score" principle
 * used everywhere else in the product).
 */

type Card = {
  /** Real photo, once available — e.g. "/brand/portraits/member-1.jpg". */
  photoSrc?: string;
  gradient: string;
  rotate: string;
  translateY: string;
  size: "lg" | "md" | "sm";
};

const CARDS: Card[] = [
  {
    gradient: "linear-gradient(160deg, var(--accent-soft) 0%, var(--bg-sunken) 100%)",
    rotate: "-rotate-[6deg]",
    translateY: "sm:-translate-y-2",
    size: "lg",
  },
  {
    gradient: "linear-gradient(160deg, var(--bg-sunken) 0%, #EFE4CE 100%)",
    rotate: "rotate-[3deg]",
    translateY: "sm:translate-y-4",
    size: "md",
  },
  {
    gradient: "linear-gradient(160deg, var(--accent-soft) 0%, #F6EEE3 100%)",
    rotate: "-rotate-[2deg]",
    translateY: "sm:-translate-y-4",
    size: "lg",
  },
  {
    gradient: "linear-gradient(160deg, #F6EEE3 0%, var(--accent-soft) 100%)",
    rotate: "rotate-[5deg]",
    translateY: "sm:translate-y-2",
    size: "md",
  },
  {
    gradient: "linear-gradient(160deg, var(--bg-sunken) 0%, var(--accent-soft) 100%)",
    rotate: "-rotate-[4deg]",
    translateY: "sm:-translate-y-1",
    size: "sm",
  },
];

const SIZE_CLASS: Record<Card["size"], string> = {
  lg: "aspect-[3/4]",
  md: "aspect-[3/4]",
  sm: "aspect-[4/5]",
};

function PortraitCard({ card }: { card: Card }) {
  return (
    <div
      className={`relative rounded-2xl overflow-hidden shadow-sm transition-transform duration-300 hover:-translate-y-1 ${card.rotate} ${card.translateY} ${SIZE_CLASS[card.size]}`}
      style={{
        background: card.gradient,
        border: "1px solid var(--line)",
      }}
      aria-hidden="true"
    >
      {card.photoSrc ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={card.photoSrc} alt="" className="w-full h-full object-cover" />
      ) : (
        <svg
          viewBox="0 0 100 120"
          className="absolute inset-0 w-full h-full"
          preserveAspectRatio="xMidYMax slice"
        >
          <circle cx="50" cy="42" r="20" fill="var(--text)" opacity="0.08" />
          <path
            d="M 8 118 C 8 88 26 70 50 70 C 74 70 92 88 92 118 Z"
            fill="var(--text)"
            opacity="0.08"
          />
        </svg>
      )}
    </div>
  );
}

export function PortraitCollage() {
  return (
    <div
      className="grid grid-cols-3 sm:grid-cols-5 gap-3 sm:gap-4 w-full max-w-xl mx-auto"
      role="presentation"
    >
      {CARDS.map((card, i) => (
        <div key={i} className={i === 4 ? "hidden sm:block" : undefined}>
          <PortraitCard card={card} />
        </div>
      ))}
    </div>
  );
}
